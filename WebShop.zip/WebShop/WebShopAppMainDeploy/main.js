AOS.init();

class Card {
    Title;
    Image;
    Link;

    constructor(title, img, link) {
        this.Title = title;
        this.Image = img;
        this.Link = link;

        cardArray.push(this)
    }
}

const container = document.querySelector(".project-container");
const projectContainer = document.querySelector(".projects");
const footer = document.querySelector(".footer");

const bodyElement = document.querySelector("body");

const activeClassHeader = document.querySelector(".active");
const firstScroll = document.querySelectorAll(".firstScroll");
const secondScroll = document.querySelectorAll(".secondScroll");
const thirdScroll = document.querySelectorAll(".thirdScroll");

let allProjectCards = document.getElementsByClassName("jschange");
let anchorArray = document.querySelectorAll(".anchor");

let cardArray = new Array();

let Card1 = new Card("Travel Georgia", "source/project-step.png", "https://nktptravel.netlify.app/");
let Card2 = new Card("TeenShop", "source/teen-shop.png", "https://teenshop.ge");
let Card3 = new Card("Tech Shop", "source/template.png", "link da kaicxovreba")
let Card4 = new Card("Nature", "source/template2.png", "sadaa")

function changeCss() {
    const bodyElement = document.querySelector("body");
    const headerOuterContainer = document.querySelector(".header-container-outer");
    const activeHeader = document.querySelector(".firstScroll");
    const headerFirst = document.querySelector("#headerFirst");

    if (this.scrollY >= 454) {
        headerOuterContainer.style.background = "rgb(32, 29, 29)"
        headerOuterContainer.style.borderBottom = "3px solid #04BBBB"
        headerFirst.style.color = "#04BBBB"
        activeHeader.style.color = "#04BBBB"

    } else {
        headerOuterContainer.style.background = "rgb(4, 187, 187)"
        headerOuterContainer.style.border.bottom = "none"
        headerFirst.style.color = "rgb(12, 83, 83)"
        firstScroll[0].style.color = "#fff"
        firstScroll[0].style.fontWeight = "500"
        secondScroll[0].style.color = "#fff"
        secondScroll[0].style.fontWeight = "500"
        thirdScroll[0].style.color = "#fff"
        thirdScroll[0].style.fontWeight = "500"
    }

    if (this.scrollY >= 454 && this.scrollY < 2396.5) {
        firstScroll[0].style.fontWeight = "500"
        firstScroll[0].style.color = "rgb(4, 187, 187)"
        secondScroll[0].style.color = "#fff"
        secondScroll[0].style.fontWeight = "500"
        thirdScroll[0].style.color = "#fff"
        thirdScroll[0].style.fontWeight = "500"
    }

    if (this.scrollY >= 2396.5) {
        firstScroll[0].style.color = "#fff"
        firstScroll[0].style.fontWeight = "500"
        secondScroll[0].style.fontWeight = "500"
        secondScroll[0].style.color = "rgb(4, 187, 187)"
        thirdScroll[0].style.color = "#fff"
        thirdScroll[0].style.fontWeight = "500"
    }

    if (this.scrollY >= 3218.9) {
        thirdScroll[0].style.fontWeight = "500"
        thirdScroll[0].style.color = "rgb(4, 187, 187)"
        firstScroll[0].style.color = "#fff"
        firstScroll[0].style.fontWeight = "500"
        secondScroll[0].style.color = "#fff"
        secondScroll[0].style.fontWeight = "500"
    }
}

firstScroll.forEach(e => {
    e.addEventListener("click", function() {
        document.querySelector("header").scrollIntoView({
            behavior: 'smooth'
        })
    })
});

secondScroll.forEach(e => {
    e.addEventListener("click", function() {
        document.querySelector(".offers-section").scrollIntoView({
            behavior: 'smooth'
        })
    })
});

thirdScroll.forEach(e => {
    e.addEventListener("click", function() {
        document.querySelector(".contact").scrollIntoView({
            behavior: 'smooth'
        })
    })
});

cardArray.forEach(o => {
    AddHTML(o, container)
});

window.addEventListener("scroll", changeCss, false);

activeClassHeader.addEventListener("click", function() {
    bodyElement.scrollY = 500
});

function GenerateInnerHTML(o) {
    return `<div data-aos="zoom-in" class="card jschange" style="width: 18rem;">
               <div class="card-body">
                    <p class="card-text">${o.Title}</p>
               </div>
                <a href=${o.Link} target="_blank">
                    <img class="card-img-top" src=${o.Image} alt="Card image cap">
                </a>
           </div>`
}

function AddHTML(o, container) {
    container.innerHTML += GenerateInnerHTML(o)
}